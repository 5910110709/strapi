const sizes = {
  header: {
    height: '6rem',
  },
  leftMenu: {
    height: '6rem',
    width: '24rem',
  },
};

export default sizes;
