import styled from 'styled-components';

const Action = styled.div`
  display: flex;
  justify-content: flex-end;
`;

export default Action;
