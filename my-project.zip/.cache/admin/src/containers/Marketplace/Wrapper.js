import styled from 'styled-components';

const Wrapper = styled.div`
  padding: 18px 30px !important;
  > div:first-child {
    margin-bottom: 11px;
  }
`;

export default Wrapper;
