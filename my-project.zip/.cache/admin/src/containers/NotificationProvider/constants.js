/*
 *
 * NotificationProvider constants
 *
 */

export const SHOW_NOTIFICATION = 'app/NotificationProvider/SHOW_NOTIFICATION';
export const HIDE_NOTIFICATION = 'app/NotificationProvider/HIDE_NOTIFICATION';
