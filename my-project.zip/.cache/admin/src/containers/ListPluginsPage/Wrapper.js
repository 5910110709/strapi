import styled from 'styled-components';

const Wrapper = styled.div`
  padding: 18px 30px !important;
  overflow: hidden;
`;

export default Wrapper;
