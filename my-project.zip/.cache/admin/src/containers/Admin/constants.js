/*
 *
 * Admin constants
 *
 */

export const EMIT_EVENT = 'app/Admin/EMIT_EVENT';
export const SET_APP_ERROR = 'StrapiAdmin/Admin/SET_APP_ERROR';
