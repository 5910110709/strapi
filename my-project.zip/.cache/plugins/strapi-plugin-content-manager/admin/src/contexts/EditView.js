import { createContext } from 'react';

const EditViewContext = createContext();

export default EditViewContext;
