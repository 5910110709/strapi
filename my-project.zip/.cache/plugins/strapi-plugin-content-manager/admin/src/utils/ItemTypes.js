export default {
  COMPONENT: 'component',
  EDIT_FIELD: 'editField',
  EDIT_RELATION: 'editRelation',
  FIELD: 'field',
  RELATION: 'relation',
};
