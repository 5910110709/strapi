import styled from 'styled-components';

const Wrapper = styled.div`
  display: flex;
  margin-bottom: 6px;
`;

export { Wrapper };
