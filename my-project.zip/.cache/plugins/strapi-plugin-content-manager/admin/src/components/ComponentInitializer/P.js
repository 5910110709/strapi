import styled from 'styled-components';

const P = styled.p`
  color: #9ea7b8;
  font-size: 13px;
  font-weight: 500;
`;

export default P;
