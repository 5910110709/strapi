import styled from 'styled-components';

const Div = styled.div`
  margin-top: -2px;
`;

export default Div;
