import styled from 'styled-components';

const Enumeration = styled.input`
  position: absolute;
  top: 0;
  z-index: -1;
  visibility: hidden;
`;

export default Enumeration;
